#ifndef ClasseLedPisca_h
#define ClasseLedPisca_h

#include "Arduino.h"

class PiscaLed {
    public:
  PiscaLed(byte pinLed, int tempoPisca = 1000);
  void play();
  void stop();
  void loop();
    private:
  unsigned long delayPisca;
  bool estadoPisca;
  byte pino;
  int tempo;
 };
 #endif